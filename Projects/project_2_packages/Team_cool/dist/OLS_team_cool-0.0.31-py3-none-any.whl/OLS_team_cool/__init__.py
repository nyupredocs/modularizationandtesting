from . import ols

from .ols import OLS
